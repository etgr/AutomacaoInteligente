% onemax
function fitness=oneMax(pop)
fitness=sum(pop,2)';    
